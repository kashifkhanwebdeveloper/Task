import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  var result = "";

  Widget btn(var text) {
    return ElevatedButton(
        onPressed: () {
          setState(() {
            result = result + text;
          });
        },
        style: ElevatedButton.styleFrom(
          primary: Colors.yellowAccent,
          shape: CircleBorder(),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 50,
            color: Colors.black,
          ),
        ));
  }

  clear() {
    setState(() {
      result = "";
    });
  }

  output() {
    Parser p = Parser();
    Expression exp = p.parse(result);
    ContextModel cm = ContextModel();
    double eval = exp.evaluate(EvaluationType.REAL, cm);

    setState(() {
      result = eval.toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        //backgroundColor: Color(0xff1ca335),
        centerTitle: true,
        title: Text(
          "CALCULATOR",
          style: TextStyle(color: Color(0xDD000000)),
        ),
        backgroundColor: Colors.yellowAccent[400],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text(
            result,
            style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              btn("7"),
              btn("8"),
              btn("9"),
              ElevatedButton(
                onPressed: clear,
                child: Text(
                  "C",
                  style: TextStyle(fontSize: 50),
                ),
                style: ElevatedButton.styleFrom(
                  shape: CircleBorder(),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              btn("4"),
              btn("5"),
              btn("6"),
              btn("-"),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              btn("1"),
              btn("2"),
              btn("3"),
              btn("+"),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              btn("0"),
              ElevatedButton(
                onPressed: output,
                child: Text(
                  "=",
                  style: TextStyle(fontSize: 50),
                ),
                style: ElevatedButton.styleFrom(
                  shape: CircleBorder(),
                ),
              ),
              btn("*"),
              btn("/"),
            ],
          ),
          Text(
            "Developed By Kashif Khan",
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFFFFEE58)),
          ),
        ],
      ),
    );
  }
}
